<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Seda\\Providers\\SedaServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Seda\\Providers\\SedaServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);