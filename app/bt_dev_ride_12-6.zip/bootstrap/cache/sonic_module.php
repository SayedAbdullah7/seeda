<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Sonic\\Providers\\SonicServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Sonic\\Providers\\SonicServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);