<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Ozgo\\Providers\\OzgoServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Ozgo\\Providers\\OzgoServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);