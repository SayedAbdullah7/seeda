<?php

namespace App\services\subscription;

use App\Enums\SubscribationStatus;
use App\Http\Requests\SubscribRequest;
use App\Models\Subscriber;

class subscriberService
{
    public static function Subscriber($request,$model){
        $data = $request->validated();
        $data["subscribable_type"] = get_class($model);
        $data["subscribable_id"] = $model->id;
        $data["status"] = SubscribationStatus::active;

        return Subscriber::create($data);
    }
}