<?php

namespace App\EnumStatus;

class PaymentWays
{
    const mobileWallet = 'mobileWallet';
    const card = 'card';
}
