<?php
namespace App\EnumStatus;

class paymentStatus
{
    const pending = 'pending';
    const success = 'success';
    const failed = 'failed';
}
