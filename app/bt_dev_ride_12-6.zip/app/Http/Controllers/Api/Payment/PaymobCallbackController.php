<?php

namespace App\Http\Controllers\Api\Payment;

use App\EnumStatus\paymentStatus;
use App\Http\Controllers\Controller;
use App\Integrations\payment\factory\Paymob;
use App\Models\Card;
use App\Models\Order;
use App\Models\PaymentTranscation;
use App\Models\PriceConfig;
use App\Models\User;
use App\Models\Vehicles;
use App\Response\ApiResponse;
use App\services\Gps\sdnService;
use App\services\HttpService;
use App\services\order\OrderDetailsService;
use App\services\walletService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Modules\Sonic\Transformers\OrderResource;

class PaymobCallbackController extends Controller
{
    private walletService $walletService;

    public function __construct()
    {
        $this->walletService = new walletService();
    }
    public function callback(Request $request){
        $data = $request->all();
        $trancaction = (new Paymob(new User(),22,"",""))->getTrancaction($data["id"]);
        $resp = $trancaction->json();
        $user = User::where("phone",$resp['billing_data']["phone_number"])->where("appKey",$resp['billing_data']["extra_description"])->first();
        $order = PaymentTranscation::where("user_id",$user->id)->latest()->first();
        $success =filter_var($data['success'], FILTER_VALIDATE_BOOLEAN);

        if ($success){
            if ($order->is_wallet){
                $this->walletService->chargeAnthoerUser($order->amount,$order->user_id);
                $order->update(["status"=>paymentStatus::success]);
                if ($order->is_save){
                    $card = Card::Where('cardable_id',$user->id)->latest()->first();
                    return (new ApiResponse(200,__("api.walletChargedSuccessfully"),[
                        "card_id"=>$card->id
                    ]))->send();
                }
                return (new ApiResponse(200,__("api.walletChargedSuccessfully"),[]))->send();
            }elseif ($order->is_order){
                if ($order->order_ended){
                    $userOrder = Order::where("user_id",$order->user_id)->
                    where("appKey",$resp['billing_data']["extra_description"])->latest()->first();
                    return (new ApiResponse(200,__("api.scooterOrderEndedSuccessfully"),["data"=>new OrderResource($userOrder)]))->send();
                }else{
                    return $this->completeOrder($order->user_order_id,$resp['billing_data']["extra_description"]);
                }
            }
        }else{
            if ($order->is_wallet){
                return;
            }elseif ($order->is_order){
                if ($order->order_ended){
                    (new walletService())->depositFromUser($order->amount,$order->user_id);
                    return (new ApiResponse(200,__("api.failToPayAndAddedToWallet"),["data"=>new OrderResource($order)]))->send();
                }else{
                    $order->delete();
                    return (new ApiResponse(406,__("api.failedPaid"),[]))->send();
                }
            }
        }
    }

    private function completeOrder($user_order_id,$appKey){
        $order = Order::find($user_order_id);

        $vehicle = Vehicles::with("VehicleColor")->where("id",$order->scooter_id)->first();
        $price = PriceConfig::where("shipment_type_id",$order->shipment_type_id)
            ->where("ride_types_id",$vehicle->ride_types_id)->first();

        $check = sdnService::unlockCallback($vehicle,$appKey);
        if ($check ){
            OrderDetailsService::Create($order->id);
            OrderDetailsService::startTime($order->id);

            $order->update(["end_at"=>now()->addMinutes(60)]);
            $vehicle->update(["is_open"=>true]);

            return (new ApiResponse(200,__("api.scooterOrderCreatedSuccessfully"),[
                "data"=>new OrderResource($order),
                "time"=>60,
                "minute_price"=>$price->move_minute_price,
                "fixed_fees"=>$price->fixed_fees,
                "color"=>$vehicle->VehicleColor->code,
                "order_id"=>$order->id,
                "battery"=>intval($vehicle->battary),
            ]))->send();
        }
        $order->delete();
        return (new ApiResponse(406,__("api.TryAgainSomeErrorHappened"),[]))->send();
    }

    public function saveTokenCallbackSonic(Request $request){
        $data = $request->all();
        $user = User::where("email",$data["obj"]["email"])->where("appKey","527")->first();
        $order = PaymentTranscation::where("user_id",$user->id)->latest()->first();
        if ($order->is_save){
            $this->saveCard($user,$user->appKey,$data);
        }
    }

    private function saveCard($user,$appKey, array $data)
    {
        Card::create([
            "cardable_type"=>User::class,
            "cardable_id"=>$user->id,
            "token"=>$data["obj"]["token"],
            "cardDigits"=>$data["obj"]["masked_pan"],
            "appKey"=>$appKey,
        ]);
    }

}

