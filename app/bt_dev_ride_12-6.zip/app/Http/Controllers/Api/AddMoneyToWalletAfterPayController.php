<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\AddMoneyToWalletAfterPayRequest;
use App\Models\Order;
use App\Response\ApiResponse;
use App\services\walletService;
use Illuminate\Http\Request;

class AddMoneyToWalletAfterPayController extends Controller
{
    private walletService $wallet;

    public function __construct(){
        $this->wallet = new walletService();
    }

    public function index(Request $request)
    {
        $order_id = $request->order_id;
        $amount = $request->amount;

        $order  = Order::with("OrderDetails")->where("id",$order_id)->first();

        if ($order->payment_type_id == 1){
            $rsp = $this->wallet->AddRemainToWallet($amount,$order->user_id);

            if ($rsp){
                $rsponse = new ApiResponse(200,__("api.remainAddToWallet"),[]);
            }else{
                $rsponse = new ApiResponse(406,__("api.you enter invalid amount"),[]);
            }
        }else{
            $rsponse = new ApiResponse(406,__("api.this api active for cash only"),[]);
        }
        return $rsponse->send();
    }
}
