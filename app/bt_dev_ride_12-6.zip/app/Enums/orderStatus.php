<?php 
namespace App\Enums;

class orderStatus
{
    const waiting = 'waiting';
    const accept = 'accept';
    const cancel = 'cancel';
    const start = 'start';
    const end = 'end';
}