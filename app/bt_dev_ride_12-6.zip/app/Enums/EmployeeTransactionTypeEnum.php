<?php

namespace App\Enums;

enum EmployeeTransactionTypeEnum: string
{
    case chargeuserwallet = 'chargeuserwallet';
}
