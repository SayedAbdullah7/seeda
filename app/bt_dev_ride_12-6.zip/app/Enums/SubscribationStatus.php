<?php

namespace App\Enums;

class SubscribationStatus
{
    const active = 'active';
    const inActive = 'inActive';
    const ended = 'ended';
}