<?php

namespace App\Enums;

enum mediaableEnum: string
{
    case user = 'user';
    case order = 'order';
    case vehicle = 'vehicle';
}
