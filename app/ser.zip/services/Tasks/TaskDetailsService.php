<?php

namespace App\services\Tasks;

class TaskDetailsService
{

}